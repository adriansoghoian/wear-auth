# Trace processing script

from dtw import *
import time, statistics


def import_datalabels(filename):
	data = []
	data_dict = {}
	for line in open(filename):
		data_dict = {}
		line_items = line.split(',')
		data_dict["id"] = line_items[0].rstrip()
		data_dict["wearer"] = line_items[1].rstrip()
		data_dict["gesture"] = line_items[2].rstrip()
		data.append(data_dict)
	return data


def import_trace(filename):
	x = [] 
	y = [] 
	z = []
	for line in open(filename):
		#print "line is %s" % line
		#print line.split('\t')
		x_temp, y_temp, z_temp, dummy = line.split('\t')
		x.append(float(x_temp))
		y.append(float(y_temp))
		z.append(float(z_temp))
	return x, y, z


def compare_traces(traces_1, traces_2):
	x_trace1 = traces_1[0]
	y_trace1 = traces_1[1]
	z_trace1 = traces_1[2]
	x_trace2 = traces_2[0]
	y_trace2 = traces_2[1]
	z_trace2 = traces_2[2]
	x_dist = dtw(x_trace1, x_trace2)
	y_dist = dtw(y_trace1, y_trace2)
	z_dist = dtw(z_trace1, z_trace2)
	return (x_dist + y_dist + z_dist) / 3.0

if __name__ == '__main__':
	
	# toggle the below two lines if you're switching between the original run and 
	# the second run.  The primary difference is that the second run had no lower-
	# bound threshold for logging the wear device's accelerometer readings.
	# To-do: generate the "bad_trace_list" off of the labels file itself... no need to do that manually
	# like we are here...
	dir_str = "Wear Auth Docs 2/"
	bad_trace_list = [6,7,62,64,65,66,67]
	#dir_str = "Wear Auth Docs/"
	#bad_trace_list = [6, 42, 72, 73, 80]


	filename_prefix = "myfile"
	filename_postfix = ".txt"
	trace_list = []
	labels_file = "Gesture Recordings.csv"
	wearer_list = ["Geoffrey", "Yukti", "Adrian"]
	gesture_list = ["Left to Right Line", "Square", "Quadrants", "Sat Night Fever", "Salute", "ZQuadrants"]

	num_traces = 96
	for i in range(96):
		i_string = "%02d" % i
		trace_list.append(import_trace(dir_str + filename_prefix + i_string + filename_postfix))
	print "<%s> Read in %s traces." % (time.ctime(), len(trace_list))


	data_labels = import_datalabels(dir_str+labels_file)
	print "<%s> Read in %s labels." % (time.ctime(), len(data_labels))

	gesture_x_wearer = {}
	g_x_w_mean = {}
	g_x_w_std = {}
	for gesture in gesture_list:
		gesture_x_wearer[gesture] = {}
		g_x_w_mean[gesture] = {}
		g_x_w_std[gesture] = {}
		for wearer in wearer_list:
			gesture_x_wearer[gesture][wearer] = []
			g_x_w_mean[gesture][wearer] = -1
			g_x_w_std[gesture][wearer] = -1

	for i, trace in enumerate(trace_list):
		if i in bad_trace_list:
			print "skipping %s" % i
			continue
		else:
			gesture_x_wearer[data_labels[i]['gesture']][data_labels[i]['wearer']].append(trace)


	for wearer in wearer_list:
		for gesture in gesture_list:
			temp_scores = []
			traces = gesture_x_wearer[gesture][wearer]
			for i in range(0,len(traces)-1):
				for j in range(i+1, len(traces)):
					temp_scores.append(compare_traces(traces[i], traces[j]))
					if(wearer == "Geoffrey" and gesture == "Square"):
						print "i=%s, j=%s, dtw=%s" % (i, j, temp_scores[-1])
			if(wearer == "Geoffrey" and gesture == "Square"):
				print temp_scores
			g_x_w_mean[gesture][wearer] = statistics.mean(temp_scores)
			g_x_w_std[gesture][wearer] = statistics.stdev(temp_scores)
	print "<%s> Calculated within-group distances." % time.ctime()

	outfile = "within_group_results.csv"
	with open(dir_str + outfile, 'w') as f:
		out_str = ","
		for g in gesture_list:
			out_str += g + ","
		out_str += '\n'
		f.write(out_str)
		cumm_ave_g = {}
		for g in gesture_list: cumm_ave_g[g] = 0
		for w in wearer_list:
			out_str = w + ","
			cumm_ave_w = 0
			for g in gesture_list:
				out_str += "%.02f +/- %.02f," % (g_x_w_mean[g][w], g_x_w_std[g][w])
				cumm_ave_w += g_x_w_mean[g][w]
				cumm_ave_g[g] += g_x_w_mean[g][w]
			out_str += "%.02f\n" % (cumm_ave_w / len(gesture_list))
			f.write(out_str)

		out_str = ","
		for g in gesture_list:
			out_str += "%.02f," % (cumm_ave_g[g] / len(wearer_list))
		f.write(out_str)
	print "<%s> Printed within-group distances." % time.ctime()

	outfile_2 = "across_group_results.csv"
	cross_scores = {}
	for gesture in gesture_list:
		cross_scores[gesture] = {}
		for i in range(0, len(wearer_list) - 1):
			for j in range(i, len(wearer_list)):
				w_1 = wearer_list[i]
				w_2 = wearer_list[j]
				if w_1 == w_2:
					continue
				else:
					cross_scores[gesture][w_1 + w_2] = []
					measurements_1 = gesture_x_wearer[gesture][w_1]
					measurements_2 = gesture_x_wearer[gesture][w_2]
					for m1 in measurements_1:
						for m2 in measurements_2:
							cross_scores[gesture][w_1 + w_2].append(compare_traces(m1, m2))
	print "<%s> Calculated across-gesture distances." % time.ctime()

	with open(dir_str + outfile_2, "w") as f:
		out_str = ","
		for g in gesture_list:
			out_str += g + ","
		out_str += '\n'
		f.write(out_str)
		for i in range(0, len(wearer_list) - 1):
			for j in range(i, len(wearer_list)):
				w_1 = wearer_list[i]
				w_2 = wearer_list[j]
				if w_1 == w_2:
					continue
				else:
					out_str = w_1 + " vs. " + w_2 + ","
					for gesture in gesture_list:
						out_str += "%.02f [%.02f]," % (min(cross_scores[gesture][w_1 + w_2]), statistics.mean(cross_scores[gesture][w_1 + w_2]) )
					out_str += "\n"
					f.write(out_str)

	print "<%s> Printed across-gesture distances." % time.ctime()