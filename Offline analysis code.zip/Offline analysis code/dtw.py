import math

def distance(x, y):
	"""
	L1 distance between two discrete values. 
	"""
	return math.fabs(x - y)

def dtw(series_1, series_2):
	"""
	Computes the Dynamic Time Warping Distance between two numeric, 1D sequences. 
	Uses L1 distances and assumes monotonicity. 
	"""
	cost_x = len(series_1) + 1
	cost_y = len(series_2) + 1
	cost = [ [None]*cost_y for i in range(cost_x) ]

	for i in range(1, cost_x):
	    cost[i][0] = float('inf')
	for i in range(1, cost_y):
	    cost[0][i] = float('inf')
	cost[0][0] = 0

	for i, x in enumerate(range(1, cost_x)):
	    for j, y in enumerate(range(1, cost_y)):
	        temp = distance(series_1[i], series_2[j])
	        cost[x][y] = temp + min(cost[x - 1][y], cost[x][y - 1], cost[x - 1][y - 1])

	return cost[cost_x - 1][cost_y - 1]